CREATE DATABASE  IF NOT EXISTS "lubm1" /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `lubm1`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: obdalin3.inf.unibz.it    Database: lubm1
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `researchgroups`
--

DROP TABLE IF EXISTS `researchgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `researchgroups` (
  `depid` smallint(6) NOT NULL,
  `uniid` smallint(6) NOT NULL,
  `id` smallint(6) NOT NULL,
  PRIMARY KEY (`id`,`depid`,`uniid`),
  KEY `fk_researchgroups_1` (`depid`,`uniid`),
  CONSTRAINT `fk_researchgroups_1` FOREIGN KEY (`depid`, `uniid`) REFERENCES `departments` (`departmentid`, `universityid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `researchgroups`
--

LOCK TABLES `researchgroups` WRITE;
/*!40000 ALTER TABLE `researchgroups` DISABLE KEYS */;
INSERT INTO `researchgroups` VALUES (0,0,0),(0,0,1),(0,0,2),(0,0,3),(0,0,4),(0,0,5),(0,0,6),(0,0,7),(0,0,8),(0,0,9),(1,0,0),(1,0,1),(1,0,2),(1,0,3),(1,0,4),(1,0,5),(1,0,6),(1,0,7),(1,0,8),(1,0,9),(1,0,10),(1,0,11),(1,0,12),(1,0,13),(1,0,14),(1,0,15),(1,0,16),(1,0,17),(1,0,18),(2,0,0),(2,0,1),(2,0,2),(2,0,3),(2,0,4),(2,0,5),(2,0,6),(2,0,7),(2,0,8),(2,0,9),(2,0,10),(2,0,11),(2,0,12),(3,0,0),(3,0,1),(3,0,2),(3,0,3),(3,0,4),(3,0,5),(3,0,6),(3,0,7),(3,0,8),(3,0,9),(3,0,10),(3,0,11),(3,0,12),(3,0,13),(3,0,14),(3,0,15),(3,0,16),(3,0,17),(4,0,0),(4,0,1),(4,0,2),(4,0,3),(4,0,4),(4,0,5),(4,0,6),(4,0,7),(4,0,8),(4,0,9),(4,0,10),(4,0,11),(4,0,12),(4,0,13),(4,0,14),(4,0,15),(4,0,16),(4,0,17),(4,0,18),(4,0,19),(5,0,0),(5,0,1),(5,0,2),(5,0,3),(5,0,4),(5,0,5),(5,0,6),(5,0,7),(5,0,8),(5,0,9),(5,0,10),(5,0,11),(5,0,12),(5,0,13),(6,0,0),(6,0,1),(6,0,2),(6,0,3),(6,0,4),(6,0,5),(6,0,6),(6,0,7),(6,0,8),(6,0,9),(6,0,10),(6,0,11),(6,0,12),(6,0,13),(6,0,14),(6,0,15),(7,0,0),(7,0,1),(7,0,2),(7,0,3),(7,0,4),(7,0,5),(7,0,6),(7,0,7),(7,0,8),(7,0,9),(7,0,10),(7,0,11),(7,0,12),(7,0,13),(7,0,14),(7,0,15),(7,0,16),(7,0,17),(7,0,18),(7,0,19),(8,0,0),(8,0,1),(8,0,2),(8,0,3),(8,0,4),(8,0,5),(8,0,6),(8,0,7),(8,0,8),(8,0,9),(8,0,10),(8,0,11),(8,0,12),(8,0,13),(8,0,14),(8,0,15),(8,0,16),(8,0,17),(9,0,0),(9,0,1),(9,0,2),(9,0,3),(9,0,4),(9,0,5),(9,0,6),(9,0,7),(9,0,8),(9,0,9),(9,0,10),(9,0,11),(10,0,0),(10,0,1),(10,0,2),(10,0,3),(10,0,4),(10,0,5),(10,0,6),(10,0,7),(10,0,8),(10,0,9),(10,0,10),(10,0,11),(10,0,12),(10,0,13),(10,0,14),(11,0,0),(11,0,1),(11,0,2),(11,0,3),(11,0,4),(11,0,5),(11,0,6),(11,0,7),(11,0,8),(11,0,9),(11,0,10),(11,0,11),(11,0,12),(12,0,0),(12,0,1),(12,0,2),(12,0,3),(12,0,4),(12,0,5),(12,0,6),(12,0,7),(12,0,8),(12,0,9),(12,0,10),(13,0,0),(13,0,1),(13,0,2),(13,0,3),(13,0,4),(13,0,5),(13,0,6),(13,0,7),(13,0,8),(13,0,9),(13,0,10),(13,0,11),(13,0,12),(14,0,0),(14,0,1),(14,0,2),(14,0,3),(14,0,4),(14,0,5),(14,0,6),(14,0,7),(14,0,8),(14,0,9),(14,0,10),(14,0,11);
/*!40000 ALTER TABLE `researchgroups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-08 11:17:45
